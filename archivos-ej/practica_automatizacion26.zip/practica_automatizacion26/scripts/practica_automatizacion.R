
#Paquetes#

install.packages("rnaturalearth")
install.packages("ecospat")
install.packages("terra")

library(rnaturalearth)
library(ggplot2)
library(ecospat)
library(terra)
library(dplyr)
library(readr)
library(purrr)
library(here)
library(ade4)
library(sf)
library(fs)

#

#Cargar las distribuciones geográficas
Uroderma_disGeo <- read_sf(here("archivos-ej", "practica_automatizacion26" , "inputs", "Uroderma_distGeo.shp"))

#Carcar las áreas de accesibilidad
Uroderma_AreAcc <- read_sf(here("archivos-ej", "practica_automatizacion26" , "inputs", "Uroderma_AreAcc.shp"))

#¿Cuáles y cuántas especies tenemos?
unique(Uroderma_disGeo$Species)

#Polígono base (fondo)
World <- ne_countries() 

#Visualizar las áreas de distribución
ggplot() +
  geom_sf(data = World,
          fill = "gray80",
          color = "gray80") +
  geom_sf(data = Uroderma_disGeo, aes(fill = Species),
          alpha = 0.3) +
  coord_sf(xlim = c(st_bbox(Uroderma_disGeo)[1], st_bbox(Uroderma_disGeo)[3]),
           ylim = c(st_bbox(Uroderma_disGeo)[2], st_bbox(Uroderma_disGeo)[4]),
           crs = 4326) +
  theme_classic()

#Visualizar las áreas accesibles
ggplot() +
  geom_sf(data = World,
          fill = "gray80",
          color = "gray80") +
  geom_sf(data = Uroderma_AreAcc, aes(fill = species),
          alpha = 0.3) +
  coord_sf(xlim = c(st_bbox(Uroderma_AreAcc)[1], st_bbox(Uroderma_AreAcc)[3]),
           ylim = c(st_bbox(Uroderma_AreAcc)[2], st_bbox(Uroderma_AreAcc)[4]),
           crs = 4326) +
  theme_classic()


#Filtrar el polígono de distribución para una especie
U_bakeri <- Uroderma_disGeo |> 
  filter(Species == "Uroderma_bakeri") |> 
  st_make_valid()

U_bakeri_AA <- Uroderma_AreAcc |> 
  filter(species == "Uroderma_bakeri") |> 
  st_make_valid()

#¿Cómo se ven?

ggplot() +
  geom_sf(data = World,
          fill = "gray80",
          color = "gray80") +
  geom_sf(data = U_bakeri_AA,
          aes(fill = Species),
          fill = "#5984d9") +
  geom_sf(data = U_bakeri,
          aes(fill = Species),
          fill = "#f54545",
          alpha = 0.5) +
  coord_sf(xlim = c(st_bbox(U_bakeri_AA)[1], st_bbox(U_bakeri_AA)[3]),
           ylim = c(st_bbox(U_bakeri_AA)[2], st_bbox(U_bakeri_AA)[4])) +
  theme_classic()


#===============================================================================

#Aquí siguen una serie de pasos intermedios que por términos de tiempo y finalidades de la práctica no veremos.
#En concreto:
#Obtener los puntos (latitud y longitud) de los centroides de las celdas.
   #Para distribuciones geográficas y áreas de accesibilidad
#Extraer los climas a partir de los puntos

#En la carpeta 'inputs' ya tenemos estas coordenadas

occPoints <- dir_map(path = here("Archivos-ej", "practica_automatizacion26", "inputs","occPoints"), read_csv)

occPoints[[1]] |> 
  head()

AreAccPoints <- dir_map(path = here("Archivos-ej", "practica_automatizacion26", "inputs","AreAccPoints"), read_csv) 

AreAccPoints[[1]] |> 
  head()


#Vamos a calcular la superposición de nicho climático para un par de especies
namesUroderma <- unique(Uroderma_disGeo$Species)
namesUroderma[3]
namesUroderma[5]

ggplot() +
  geom_sf(data = World,
          fill = "gray80",
          color = "gray80") +
  geom_sf(data = st_make_valid(filter(Uroderma_disGeo, Species == namesUroderma[3])),
          aes(fill = Species),
          fill = "#5984d9",
          alpha = 0.5) +
  geom_sf(data = st_make_valid(filter(Uroderma_disGeo, Species == namesUroderma[5])),
          aes(fill = Species),
          fill = "#f54545",
          alpha = 0.5) +
  coord_sf(xlim = c(st_bbox(Uroderma_AreAcc)[1], st_bbox(Uroderma_AreAcc)[3]),
           ylim = c(st_bbox(Uroderma_AreAcc)[2], st_bbox(Uroderma_AreAcc)[4]))  +
  theme_classic()

#=================================================================================
##Preparamos los datos


##Variables climáticas
#En la carpeta '05_biosResol' ya tenemos las variables climáticas (World clim) procesadas, es decir, a la resulución deseada y cortadas a la región de interés
#Bio 1: Temperatura promedio anual
#Bio 4: Estacionalidad de la temperatura
#Bio 5: Temperatura mínima del mes más frío
#Bio 6: Temperatura máxima del mes más caliente
#Bio 12: Precipitación total anual
#Bio 13: Precipitación máxima del mes más húmedo
#Bio 14: Precipitación mínima del mes más seco
#Bio 15: Estacionalidad de la precipitación

#Stack de las variables climáticas
stackBios <- list.files(path = here("Archivos-ej", "practica_automatizacion26", "inputs", "05_biosResol"), pattern=".tif$", full.names = TRUE) |> 
  rast()

#Seleccionamos solo las columnas latitud y longitud
occ_U_convexum <- occPoints[[3]] |>  
  select(lon, lat)
occ_U_magnirostrum <- occPoints[[5]] |> 
  select(lon, lat)

Acc_U_convexum <- AreAccPoints[[3]] |> 
  select(lon, lat)
Acc_U_magnirostrum <- AreAccPoints[[5]] |> 
  select(lon, lat)

#Climas presentes en el área de distribución
clim_U_convexum <- 
  terra::extract(stackBios,
                 occ_U_convexum, 
                 xy=TRUE,
                 ID=FALSE,
                 method="simple") |> 
  mutate(sp = "Uroderma_convexum")

clim_U_magnirostrum <-
  terra::extract(stackBios, 
                 occ_U_magnirostrum,
                 xy=TRUE,
                 ID=FALSE,
                 method="simple") |> 
  mutate(sp = "Uroderma_magnirostrum")


#Climas presentes en el área de accesibilidad

clim_U_convexum_Acc <-
  terra::extract(stackBios,
                 Acc_U_convexum,
                 xy=TRUE,
                 ID=FALSE,
                 method="simple") |> 
  mutate(sp = "Uroderma_convexum")
  

clim_U_magnirostrum_Acc <- 
  terra::extract(stackBios, 
                 Acc_U_magnirostrum,
                 xy=TRUE,
                 ID=FALSE,
                 method="simple") |> 
  mutate(sp = "Uroderma_magnirostrum")

##Vamos a hacer un análisis de componentes principales
#Ajustamos los datos

dataComb <- bind_rows(clim_U_convexum_Acc, clim_U_magnirostrum_Acc) |> 
  distinct(x, y, .keep_all = TRUE) |> 
  na.omit()

varClim <- dataComb |> 
  select(!c(x, y, sp))

#PCA
PCA <- dudi.pca(varClim, center=TRUE,scale=TRUE,scannf=FALSE,nf=2)

####

##Estimar el nicho climático
#No se fijen mucho en los detalles, lo único que estamos haciendo es extraer los valores de los PC para los climas ocupados (no los del área de accesibilidad)
scrMs <- PCA$li

B1<- clim_U_convexum_Acc |> 
  select(!c(x, y, sp))
BS1 <- ade4::suprow(PCA, B1)$lisup
scrbkg1 <- cbind(clim_U_convexum_Acc, BS1) |> 
  select(Axis1, Axis2) |> 
  na.omit()


B2<- clim_U_magnirostrum_Acc |> 
  select(!c(x, y, sp))
BS2 <- ade4::suprow(PCA, B2)$lisup
scrbkg2 <- cbind(clim_U_magnirostrum_Acc, BS2) |> 
  select(Axis1, Axis2)|> 
  na.omit()


C1<- clim_U_convexum |> 
  select(!c(x, y, sp))
S1 <- suprow(PCA, C1)$lisup
scrSp1 <- cbind(clim_U_convexum, S1) |> 
  na.omit() |> 
  select(Axis1, Axis2)

C2<- clim_U_magnirostrum |> 
  select(!c(x, y, sp))
S2 <- suprow(PCA, C2)$lisup
scrSp2 <- cbind(clim_U_magnirostrum, S2) |> 
  na.omit() |> 
  select(Axis1, Axis2)


##La función ecospat.grid.clim.dyn nos estima el nicho en dos dimensiones
#Especie 1
zeta1<-ecospat::ecospat.grid.clim.dyn(scrMs,scrbkg1,scrSp1,R=100)
#Especie 2
zeta2<-ecospat::ecospat.grid.clim.dyn(scrMs,scrbkg2,scrSp2,R=100)

##La función ecospat.niche.similarity.test estima la superposición de nicho y realiza una prueba estadística (similitud de nicho)

#Solo calcula el traslape de nicho
ecospat::ecospat.niche.overlap(zeta1, zeta2, cor=TRUE) 

#¿Cómo se ve?
ecospat.plot.niche.dyn(zeta1, zeta2, quant=0.25, interest=2, title= "Niche Overlap", name.axis1="PC1", name.axis2="PC2")

#Realiza la prueba estadística
NST1 <- ecospat::ecospat.niche.similarity.test(zeta1, zeta2, rep=100)

NST1$p.D
#==============================================================================
#¿Cuántas líneas necesitamos para hacerlo para un par de especies?
#Está bien si es para unos cuántos pares, pero...

#¿Cuántos pares posibles podría haber dentro de algunos grupos de especies?

#Uroderma 5 especies
choose(5, 2)

#Sturnira 25 especies
choose(25, 2)

#Sceloporus 118 especies
choose(118, 2)

#Phyllostomidae 230 especies
choose(230, 2)

#Vespertilionidae 535 especies
choose(535, 2)


#Podemos optimizar apoyándonos con listas, bucles y funciones

##Primero extraemos los climas en un bucle y nuevamente guardamos en lista

Uroderma_ClimOcc <- list()
for (i in 1:length(namesUroderma)) {
  
  SP <- occPoints[[i]] |> 
    select(lon, lat)
  climO <-
    terra::extract(stackBios, SP, 
                   xy=TRUE, 
                   ID=FALSE, 
                   method="simple") |> 
    mutate(sp = namesUroderma[i]) |> 
    rename(lon = x, lat = y)
  
  Uroderma_ClimOcc[[i]] <- climO
}

#También para las áreas de accesibilidad
Uroderma_ClimAcc <- list()
for (i in 1:length(namesUroderma)) {
  
  BKG <- AreAccPoints[[i]] |> 
    select(lon, lat)
  climB <- 
    terra::extract(stackBios, BKG, 
                   xy=TRUE, 
                   ID=FALSE, 
                   method="simple") |> 
    mutate(sp = namesUroderma[i]) |> 
    rename(lon = x, lat = y)
  
  Uroderma_ClimAcc[[i]] <- climB
  
}

#otra alternativa: purrr::map

Uroderma_ClimOcc <- occPoints |> 
  map(\(o)
      select(o, lon, lat) |> 
      terra::extract(x = stackBios, y = o, xy=TRUE, ID=FALSE, method="simple") |> 
      rename(lon = x, lat = y)) |> 
  map2(occPoints, \(o, n) mutate(o, sp = n$sp)  #Ojo!
  )

Uroderma_AreAcc <- AreAccPoints |> 
  map(\(a)
      select(a, lon, lat) |> 
      terra::extract(x = stackBios, y = a, xy=TRUE, ID=FALSE, method="simple") |> 
      rename(lon = x, lat = y)) |> 
  map2(AreAccPoints, \(a, n) mutate(a, sp = n$sp)
  ) 


#===============================================================================
#Ahora utilizaremos unas funciones creadas para nuestro propósito específico
#En la carpeta 'scripts' se encuentra un código con 3 funciones. Lo llamamos de la siguiente manera

source(here("Archivos-ej","practica_automatizacion26","scripts", "funciones.R"))

#Las funciones se cargan en el ambiente de RStudio Las pueden explorar con detalle, pero básicamente hacen exactamente lo mismo que hicimos en los pasos anteriores

#Par 1: Uroderma bakeri vs Uroderma bilobatum

pcaPar1 <- do_pca(Uroderma_ClimAcc[[1]], Uroderma_ClimAcc[[2]])

scoresPar1 <- get_scores(Uroderma_ClimOcc[[1]],
                         Uroderma_ClimOcc[[2]],
                         Uroderma_ClimAcc[[1]],
                         Uroderma_ClimAcc[[2]],
                         pcaPar1)


Overlap_Par1 <- NicheOv_SimTest(scoresPar1, sim.test=FALSE, save.z = FALSE)
Overlap_Par1

#Ya es mucho más sencillo, pero para hacer los 10 pares posibles sigue siendo largo y es mucho más probable cometer algún error 

#Pero podemos usar nuestras funciones dentro de un bucle

#Creamos una matriz vacía para guardar nuestros resultados
DOverlap <- matrix(ncol=length(namesUroderma), nrow=length(namesUroderma), 0) 
colnames(DOverlap) <- namesUroderma
rownames(DOverlap) <- namesUroderma

k<-1
All_Results <- list()
for (i in 1:length(namesUroderma)) {

  j=i+1

  for (j in j:length(namesUroderma)) {
    
    dopca <- do_pca(Uroderma_ClimAcc[[i]], Uroderma_ClimAcc[[j]]) #Analisis de componentes principales
    
    getS <- get_scores(Uroderma_ClimOcc[[i]],
                       Uroderma_ClimOcc[[j]],
                       Uroderma_ClimAcc[[i]],
                       Uroderma_ClimAcc[[j]],
                       dopca)
    
    NO_ST <- NicheOv_SimTest(getS, sim.test = FALSE, save.z = FALSE)
    
	#Guardar los resultados en una lista
    All_Results[[k]] <- NO_ST
    
    #Guardar en nuestra matriz
    DOverlap[i,j] <- DOverlap[j,i] <- NO_ST$D
	
    print(length(All_Results))
    print(NO_ST$Sp1)
    print(NO_ST$Sp2)
	
    k<- k+1
  }
}

DOverlap
All_Results


#remove.package para remover paquetes
#remove.packages("ecospat")













