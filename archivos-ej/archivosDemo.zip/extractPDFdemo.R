# este código se basa en una publicación de Dr. Chris Brown en UTAS
# https://www.seascapemodels.org/rstats/2025/03/15/LMs-in-R-with-ellmer.html

library(ellmer) 

 

chatpdfs <- chat_openai(model = "gpt-4.1-mini",
  system_prompt = "extrae datos de artículos científicos")
  
# Preparar y codificar el PDF para la entrada del chat
mybatfile <- content_pdf_file("stenoderma.pdf")

of_interest <- 
  type_object(
  scientific_name = type_string("especie focal del documento"),
  forearm_length = type_number("longitud en milímetros del antebrazo del murciélago"),
  forearm_length_max =type_number("longitud en milímetros del valor máximo del antebrazo del murciélago"),
  forearm_length_min =type_number("longitud en milímetros del valor mínimo del antebrazo del murciélago"),
  ear_length = type_number("longitud en milímetros de la oreja o pabellón auditivo del murciélago"),
  body_mass =  type_number("peso en gramos para la especie")
)

bat_info <- chatpdfs$chat_structured("extrae los valores de los rasgos",mybatfile, type= of_interest)
bat_info

# intentar con el PDF de macrotus o intentar extraer diferentes rasgos
